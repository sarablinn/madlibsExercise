create
    definer = user@localhost procedure terminateProperty(IN companyId int, IN companyName varchar(150)) comment 'Terminate Property from Kipsu

Parameters:
- companyId - A companyId of the property to be terminated
- companyName - A companyName of the property to be terminated'
proc:BEGIN


    
    IF companyId = '' 
        THEN SELECT CONCAT('No companyID provided - Please provide a value for the Company Id');
        LEAVE proc;
    END IF;

     
    IF companyName = '' 
        THEN SELECT CONCAT('No companyName provided - Please provide a value for the Company Name');
        LEAVE proc;
    END IF;

    
    IF NOT EXISTS(SELECT 1 FROM `company` WHERE `company_id` = companyId) THEN
        SELECT CONCAT('company_id ', companyId, ' not found! Please provide a valid Company Id');
        LEAVE proc; 
    END IF;

    
    IF NOT EXISTS(SELECT 1 FROM `company` WHERE `company_name` = companyName) THEN
        SELECT CONCAT('company_name ', companyName, ' not found! Please provide a valid Company Name');
        LEAVE proc; 
    END IF;

    
    IF NOT EXISTS(SELECT 1 FROM `company` WHERE `company_name` = companyName AND `company_id` = companyId) THEN
        SELECT CONCAT('company_name ', companyName, ' not attached to company_id ', companyId, '! Please provide a matching pair');
        LEAVE proc; 
    END IF;

    
    DROP TEMPORARY TABLE IF EXISTS temp_user_id;
    DROP TEMPORARY TABLE IF EXISTS temp_loc_id;
  
    
    CREATE TEMPORARY TABLE IF NOT EXISTS temp_user_id AS (SELECT `user_id` AS user_id FROM `meta` WHERE `company_id` = companyId);
  
    
    CREATE TEMPORARY TABLE IF NOT EXISTS temp_loc_id AS (SELECT `loc_id` AS loc_id FROM `location` WHERE `company_id` = companyId);

    
    SET @procedureName := 'terminateProperty';
    SET @tablesAffected := 'company, user, meta, user_settings, reports, location_pref, goal_subscription, stored_message, location, away_messages, company_settings, message, transfer_group_membership, peer_groups_companies, parent_child, widget, number, default_location, external_system_company, external_property_id';
    SET @variablesProvided := CONCAT('companyId: ', companyId, ' companyName: ', companyName);
    
    SET SESSION group_concat_max_len = 200000;
    
    SET @phoneNumbers := ( 
        SELECT 
            GROUP_CONCAT(
                CONCAT(
                    IF(`phone_number` = '', "NONE AVAILABLE", `phone_number`), 
                    '\t\t\t', 
                    IF(`service` = '', 'NONE AVAILABLE', `service`)
                ) 
            ORDER BY 
                `service` SEPARATOR '\n')
        FROM (  SELECT 
                    `phone_number` AS `phone_number`,
                    `service` AS `service`
                FROM 
                    `number`
                WHERE 
                    `company_id` = companyId
                ORDER BY 
                    `service`) 
        AS selected_fields);
    SET @externalSystems := (
        SELECT
            GROUP_CONCAT(
                es.`label`
            ORDER BY es.`label` SEPARATOR '\n')
        FROM 
            `external_system` es
        INNER JOIN 
            `external_system_company` esc ON es.`external_system_id` = esc.`external_system_id`
        WHERE 
            esc.`company_id` = companyId
        ORDER BY
            es.`label`);
    SET @results := (
        SELECT
            IF(@phoneNumbers IS NULL, 
                (IF(@externalSystems IS NULL, 
                    'No numbers or external systems attached', 
                    @externalSystems)),
                (IF(@externalSystems IS NULL, 
                    @phoneNumbers,
                    (CONCAT(@phoneNumbers, '\n', @externalSystems)))))
    );
    SET @rowsAffected := 0;

     
    UPDATE `company`
    SET `active` = 0, `service_number` = NULL
    WHERE `company_id` = companyId;
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    UPDATE `user`
    SET `active` = 0, `role_id` = 1000, `username` = CONCAT('deleted_', `id`), `email` = CONCAT('deleted_', `email`)
    WHERE `id` IN (SELECT `user_id` FROM `temp_user_id`);
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    UPDATE `meta`
    SET `summary_email` = 'no', `reply_able` = 'no', `phone` = NULL 
    WHERE `user_id` IN (SELECT `user_id` FROM temp_user_id)
    AND `company_id` = companyId;
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    DELETE FROM `user_settings`
    WHERE `key` = CONCAT('daily_associate_leaderboard_', companyId)
    AND `user_id` IN (SELECT `user_id` FROM temp_user_id);
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    DELETE FROM `user_settings`
    WHERE `key` = CONCAT('categories_report_', companyId)
    AND `user_id` IN (SELECT `user_id` FROM temp_user_id);
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    DELETE FROM `user_settings`
    WHERE `key` = CONCAT('portfolio_', companyId)
    AND `user_id` IN (SELECT `user_id` FROM temp_user_id);
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    DELETE FROM `reports`
    WHERE `company_id` = companyId;
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    UPDATE `location_pref`
    SET `subscribed` = 'no', `email` = 'no', `sms` = 'off', `instant` = 'no'
    WHERE `loc_id` IN (SELECT `loc_id` FROM temp_loc_id);
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    DELETE FROM `goal_subscription`
    WHERE `user_id` IN (SELECT `user_id` FROM temp_user_id);
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    UPDATE `location`
    SET `type` = 'std', `active` = 0, `phone_number_id` = NULL
    WHERE `loc_id` IN (SELECT `loc_id` FROM temp_loc_id);
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    DELETE FROM `away_messages` 
    WHERE `loc_id` IN (SELECT `loc_id` FROM temp_loc_id);
    SET @rowsAffected := @rowsAffected + ROW_COUNT();
      
    
    DELETE FROM `company_settings` 
    WHERE `company_id` = companyId  
    AND `key` = 'enable_dynamic_survey';
    SET @rowsAffected := @rowsAffected + ROW_COUNT();
    
    
    UPDATE `message`
    INNER JOIN `issue` ON `issue`.`issue_id` = `message`.`issue_id`
    INNER JOIN `convo` ON `convo`.`convo_id` = `issue`.`convo_id`
    SET 
        `message`.`type` = 'scheduled_canceled',
            `message`.`text` = CONCAT(`message`.`text`, '&&&Deleted BY Kipsu Support: ', (SELECT NOW()))
    WHERE
        `convo`.`company_id` = companyId
            AND `message`.`timestamp` > UNIX_TIMESTAMP()
            AND `message`.`posted` = 0
            AND `message`.`type` = "scheduled";
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    DELETE FROM `transfer_group_membership`
    WHERE `company_id` = companyId;
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    DELETE FROM `peer_groups_companies`
    WHERE `company_id` = companyId;
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    DELETE FROM `company_settings`
    WHERE `company_id` = companyId
    AND `key` = 'number_of_rooms';
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    INSERT IGNORE INTO `parent_child` (`parent`, `child`)
    VALUES (
        (SELECT `company_id` FROM `company` WHERE `company_name` = 'Kipsu Super' AND `type` = 'parent'), 
        companyId);
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    DELETE FROM `parent_child`
    WHERE `child` = companyId
    AND parent <> (SELECT `company_id` FROM `company` WHERE `company_name` = 'Kipsu Super' AND `type` = 'parent');
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    UPDATE `widget`
    SET `api_key_id` = NULL, `phone_number_id` = NULL
    WHERE `company_id` = companyId;
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    DELETE FROM `number`
    WHERE `company_id` = companyId;
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    UPDATE `default_location`
    SET `purpose` = 'mobile-app-disabled'
    WHERE `company_id` = companyId
    AND `purpose` = 'mobile-app';
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    DELETE FROM `external_system_company`
    WHERE `company_id` = companyId;
    SET @rowsAffected := @rowsAffected + ROW_COUNT();
    
    
    DELETE FROM `external_property_id`
    WHERE `property_id` = companyId;
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

    
    UPDATE `social_auth`
    SET `active` = 0, `platform_provided_id` = CONCAT('Removed_', `platform_provided_id`)
    WHERE `loc_id` IN (SELECT `loc_id` FROM temp_loc_id);
    SET @rowsAffected := @rowsAffected + ROW_COUNT();



END;

