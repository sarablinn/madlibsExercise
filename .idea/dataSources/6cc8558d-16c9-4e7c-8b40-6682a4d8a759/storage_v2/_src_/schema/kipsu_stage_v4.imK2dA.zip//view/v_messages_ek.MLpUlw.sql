create definer = user@localhost view v_messages_ek as
select `m`.`msg_id`                   AS `msg_id`,
       `m`.`issue_id`                 AS `issue_id`,
       from_unixtime(`m`.`timestamp`) AS `msg_timestamp`,
       `m`.`text`                     AS `text`,
       `m`.`author`                   AS `author`,
       `u`.`username`                 AS `author_username`,
       `cn`.`label`                   AS `guest_name`,
       `cn`.`id`                      AS `customer_number_id`,
       `m`.`source`                   AS `source`,
       `m`.`type`                     AS `msg_type`,
       `m`.`status`                   AS `status`,
       `m`.`created_at`               AS `created_at`,
       `m`.`updated_at`               AS `updated_at`,
       `i`.`created_at`               AS `issue_created_at`,
       `i`.`updated_at`               AS `issue_updated_at`,
       `c`.`convo_id`                 AS `convo_id`,
       `c`.`sender`                   AS `sender`,
       `c`.`company_id`               AS `company_id`,
       `co`.`type`                    AS `company_type`,
       `co`.`company_name`            AS `company_name`,
       `c`.`loc_id`                   AS `loc_id`,
       `l`.`name`                     AS `location_name`
from ((((((`kipsu_stage_v4`.`message` `m` join `kipsu_stage_v4`.`issue` `i`
           on ((`i`.`issue_id` = `m`.`issue_id`))) join `kipsu_stage_v4`.`convo` `c`
          on ((`c`.`convo_id` = `i`.`convo_id`))) join `kipsu_stage_v4`.`company` `co`
         on ((`co`.`company_id` = `c`.`company_id`))) join `kipsu_stage_v4`.`location` `l`
        on ((`l`.`loc_id` = `c`.`loc_id`))) left join `kipsu_stage_v4`.`user` `u`
       on ((`u`.`id` = `m`.`author`))) left join `kipsu_stage_v4`.`customer_numbers` `cn`
      on (((`cn`.`number` = `c`.`sender`) and (`cn`.`company_id` = `co`.`company_id`))));

-- comment on column v_messages_ek.author not supported: either phone number or userID

-- comment on column v_messages_ek.created_at not supported: The timestamp of when the record was created

-- comment on column v_messages_ek.updated_at not supported: The timestamp of when the record was last updated

-- comment on column v_messages_ek.issue_created_at not supported: The timestamp of when the record was created

-- comment on column v_messages_ek.issue_updated_at not supported: The timestamp of when the record was last updated

-- comment on column v_messages_ek.sender not supported: Sender from the public (like the shopper or guest), can be email or phone

