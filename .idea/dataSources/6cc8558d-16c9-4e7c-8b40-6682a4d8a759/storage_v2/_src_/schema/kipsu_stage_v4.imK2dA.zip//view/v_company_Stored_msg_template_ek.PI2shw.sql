create definer = user@localhost view v_company_Stored_msg_template_ek as
select `c`.`company_id`                   AS `company_id`,
       `c`.`company_name`                 AS `company_name`,
       `smt`.`stored_message_template_id` AS `stored_message_template_id`,
       `smt`.`type`                       AS `type`,
       `smt`.`text`                       AS `text`,
       `smt`.`label`                      AS `label`,
       `smt`.`category`                   AS `category`,
       `smt`.`created_at`                 AS `created_at`,
       `smt`.`updated_at`                 AS `updated_at`,
       `tg`.`template_group_id`           AS `template_group_id`,
       `tg`.`name`                        AS `template_name`,
       `smc`.`id`                         AS `stored_message_category_id`,
       `smc`.`name`                       AS `cat_name`,
       `smc`.`type`                       AS `cat_type`,
       `smc`.`parent`                     AS `parent`
from (((`kipsu_stage_v4`.`stored_message_template` `smt` join `kipsu_stage_v4`.`template_group` `tg`
        on ((`tg`.`template_group_id` = `smt`.`template_group`))) join `kipsu_stage_v4`.`stored_message_categories` `smc`
       on ((`smc`.`id` = `smt`.`category`))) join `kipsu_stage_v4`.`company` `c`
      on ((`c`.`company_id` = `smc`.`company_id`)));

-- comment on column v_company_Stored_msg_template_ek.text not supported: Multiple SMSs allowed, can have a custom message break

-- comment on column v_company_Stored_msg_template_ek.created_at not supported: The timestamp of when the record was created

-- comment on column v_company_Stored_msg_template_ek.updated_at not supported: The timestamp of when the record was last updated

-- comment on column v_company_Stored_msg_template_ek.parent not supported: 0 = no parent

