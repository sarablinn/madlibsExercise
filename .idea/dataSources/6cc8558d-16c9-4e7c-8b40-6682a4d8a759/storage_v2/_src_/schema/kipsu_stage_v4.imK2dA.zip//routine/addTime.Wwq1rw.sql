create
    definer = user@localhost procedure addTime(IN DATE date)
BEGIN
	DROP TABLE IF EXISTS timeTable;
	CREATE TEMPORARY TABLE timeTable (id INT, startTime DATETIME, endTime DATETIME);
	SET @datevar = CONCAT(DATE, ' ', '00:00:00');
	SET @counter = 1;
	SET @dateEnd = CONCAT(DATE(@dateVar), ' ', '23:59:59');
	WHILE @dateVar < @dateEnd DO
		INSERT INTO timeTable VALUES(@counter, @dateVar, AddTime(@dateVar, '00:04:59'));
		SET @dateVar = AddTime(@dateVar, '00:05:00');
		SET @counter = @counter + 1;
	END WHILE;
END;

