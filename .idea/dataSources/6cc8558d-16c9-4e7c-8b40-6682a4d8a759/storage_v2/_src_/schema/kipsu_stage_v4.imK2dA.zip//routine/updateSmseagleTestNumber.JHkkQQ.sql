create
    definer = user@localhost procedure updateSmseagleTestNumber(IN authKey varchar(50), IN gatewayDeviceId int) comment 'Update the testing number for SMSEagle devices


Parameters:

- authKey - The api_key listed in group_vars/us_east_1_vpn.yml

- gatewayDeviceId - The ID from the gateway_device table, not to be mistaken for smeagle#'
proc:BEGIN



    

    SET @procedureName := 'updateSmseagleTestNumber';

    SET @tablesAffected := 'number';

    SET @variablesProvided := CONCAT('auth_key: ', authKey, 'gateway_device_id: ', gatewayDeviceId);

    SET @rowsAffected := 0;


    

    IF (authKey = '') THEN 

        SELECT ('Please provide a valid auth_key'); 

        LEAVE proc; 

    END IF; 


    

    IF (gatewayDeviceId = '') THEN 

        SELECT ('Please provide a valid gateway_device_id'); 

        LEAVE proc; 

    END IF; 


    

    IF EXISTS(SELECT 1 FROM `number` WHERE `auth_key` = authKey) THEN

        SELECT CONCAT('auth_key "', authKey, '" already assigned to this testing number! Please provide a valid auth_key from group_vars/us_east_1_vpn.yml for your respective device');

        LEAVE proc; 

    END IF;


    

    IF NOT EXISTS(SELECT 1 FROM `gateway_device` WHERE `gateway_device_id` = gatewayDeviceId) THEN

        SELECT CONCAT('gateway_device_id "', gatewayDeviceId, '" not found! Please provide a valid gateway_device_id');

        LEAVE proc; 

    END IF; 


    

    SET @phoneNumberId := 6436;

    SET @companyId := 1239;


    

	UPDATE `number` 

    SET `auth_key` = authKey, `gateway_device_id` = gatewayDeviceId

	WHERE `phone_number_id` = @phoneNumberId 

    AND `company_id` = @companyId

	LIMIT 1;

    SET @rowsAffected := @rowsAffected + ROW_COUNT();


END;

