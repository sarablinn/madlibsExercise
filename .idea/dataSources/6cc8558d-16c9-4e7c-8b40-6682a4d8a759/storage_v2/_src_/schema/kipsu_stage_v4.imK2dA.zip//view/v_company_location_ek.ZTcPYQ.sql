create definer = user@localhost view v_company_location_ek as
select `c`.`company_id`                     AS `company_id`,
       `c`.`company_name`                   AS `company_name`,
       `l`.`name`                           AS `location_name`,
       `l`.`phone_number_id`                AS `phone_number_id`,
       `n`.`phone_number`                   AS `loc_phone_number`,
       `n`.`service`                        AS `service`,
       `l`.`active`                         AS `loc_active`,
       `l`.`default_outbound`               AS `default_outbound`,
       `l`.`delegate`                       AS `delegate`,
       `l`.`call_forward_number`            AS `call_forward_number`,
       `n`.`gateway_device_id`              AS `gateway_device_id`,
       `n`.`international_number_format_id` AS `international_number_format_id`,
       `n`.`mms_enabled`                    AS `mms_enabled`
from ((`kipsu_stage_v4`.`location` `l` left join `kipsu_stage_v4`.`number` `n`
       on ((`n`.`phone_number_id` = `l`.`phone_number_id`))) join `kipsu_stage_v4`.`company` `c`
      on ((`c`.`company_id` = `l`.`company_id`)));

-- comment on column v_company_location_ek.loc_phone_number not supported: Needs to be in 15072546428 format, or can be an email

-- comment on column v_company_location_ek.loc_active not supported: If a location is no longer active, this will disable it from being viewed on the UI

-- comment on column v_company_location_ek.gateway_device_id not supported: The gateway device to use for this number

-- comment on column v_company_location_ek.international_number_format_id not supported: The id of the internationalized number format for the number

-- comment on column v_company_location_ek.mms_enabled not supported: Set to 1 if the number should be able to send mms messages, 0 if not.

