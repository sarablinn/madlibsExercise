create definer = user@localhost view v_company_reservations_ek as
select `c`.`company_id`           AS `company_id`,
       `c`.`type`                 AS `type`,
       `c`.`company_name`         AS `company_name`,
       `r`.`reservation_id`       AS `reservation_id`,
       `r`.`start_timestamp`      AS `reservation_art`,
       `r`.`end_timestamp`        AS `reservation_end`,
       `r`.`label`                AS `label`,
       `r`.`site`                 AS `site`,
       `r`.`room_number`          AS `room_number`,
       `cr`.`customer_number_id`  AS `customer_Number_id`,
       `re`.`timestamp`           AS `reservation_event_timestamp`,
       `re`.`external_machine_id` AS `external_machine_id`,
       `re`.`type`                AS `reservation_event_type`
from ((((`kipsu_stage_v4`.`company` `c` join `kipsu_stage_v4`.`reservation` `r`
         on ((`r`.`company_id` = `c`.`company_id`))) join `kipsu_stage_v4`.`customer_reservation` `cr`
        on ((`cr`.`reservation_id` = `r`.`reservation_id`))) join `kipsu_stage_v4`.`reservation_event` `re`
       on ((`re`.`reservation_id` = `r`.`reservation_id`))) join `kipsu_stage_v4`.`reservation_event_type` `rt`
      on ((`rt`.`reservation_event_type_id` = `re`.`reservation_event_type_id`)));

-- comment on column v_company_reservations_ek.reservation_id not supported: The primary key that uniquely identifies a reservation

-- comment on column v_company_reservations_ek.reservation_art not supported: A Unix timestamp representing when the reservation begins

-- comment on column v_company_reservations_ek.reservation_end not supported: A Unix timestamp representing when the reservation ends

-- comment on column v_company_reservations_ek.label not supported: An optional name for a reservation

-- comment on column v_company_reservations_ek.site not supported: An optional name of the location where the reservation is, i.e. "Building A"

-- comment on column v_company_reservations_ek.room_number not supported: An optional field indicating the room number or specific location for the reservation

-- comment on column v_company_reservations_ek.customer_Number_id not supported: Optional foreign key to the associated customer_numbers record

-- comment on column v_company_reservations_ek.reservation_event_timestamp not supported: A Unix timestamp representing when the event occured

