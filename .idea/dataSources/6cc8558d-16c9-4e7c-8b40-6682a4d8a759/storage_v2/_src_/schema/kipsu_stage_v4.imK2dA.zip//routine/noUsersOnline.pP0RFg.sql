create
    definer = user@localhost procedure noUsersOnline(IN propertyId int, IN DATE date)
BEGIN		
	
	CALL addTime(DATE); 

	
	DROP TABLE IF EXISTS userOnline;
	CREATE TEMPORARY TABLE userOnline AS (
	SELECT 
		events.user_id, events.first_name, events.last_name,
		events.occupiedEventId, events.occupiedEvent, events.occupiedTime,
		events.vacatedEventId, events.vacatedEvent, events.vacatedTime,
		@startTime := CASE
			WHEN DATE(events.occupiedTime) < DATE THEN CONCAT(DATE, " ", "00:00:00")
			ELSE events.occupiedTime
		END AS "startTime",
		@endTime := CASE 
			WHEN DATE(events.vacatedTime) > DATE THEN CONCAT(DATE, " ", "23:59:59")
			ELSE events.vacatedTime
		END AS "endTime",
		TIMEDIFF(@endTime, @startTime) AS "duration"
	FROM (
		SELECT 
				uso.user_id, m.first_name, m.last_name, 
				uso.id AS "occupiedEventId", uso.event AS "occupiedEvent", FROM_UNIXTIME(ROUND(uso.micro_timestamp)) AS "occupiedTime", 
				usv.id AS "vacatedEventId", usv.event AS "vacatedEvent", FROM_UNIXTIME(ROUND(MIN(usv.micro_timestamp))) AS "vacatedTime"
			FROM user_statuses uso
			INNER JOIN meta m USING (user_id)
			LEFT OUTER JOIN user_statuses usv
				ON usv.user_id = uso.user_id 
				AND usv.micro_timestamp > uso.micro_timestamp
				WHERE usv.event = "channel_vacated"
					AND uso.event = "channel_occupied"
					AND m.company_id = 1538
			GROUP BY uso.id
			ORDER BY first_name, occupiedTime
	) AS events
	WHERE (DATE BETWEEN DATE(occupiedTime) AND DATE(vacatedTime))
	);
	
	
	
	DROP TABLE IF EXISTS noUsersOnline;
	CREATE TEMPORARY TABLE noUsersOnline AS (SELECT *
	FROM (SELECT tt.id, tt.startTime, tt.endTime, uo.user_id, uo.first_name, uo.last_name, uo.occupiedTime, uo.vacatedTime
	FROM timeTable tt
	LEFT OUTER JOIN userOnline uo ON uo.occupiedTime < tt.endTime AND uo.vacatedTime > tt.endTime
	ORDER BY tt.startTime
	) AS onlineStatus
	WHERE occupiedTime IS NULL
	ORDER BY id);
	
	
	DROP TABLE IF EXISTS noUsersOnline2;
	DROP TABLE IF EXISTS noUsersOnline3;
	CREATE TEMPORARY TABLE noUsersOnline2 AS (SELECT * FROM noUsersOnline);
	CREATE TEMPORARY TABLE noUsersOnline3 AS (SELECT * FROM noUsersOnline);
	
	
	SET @startId = (SELECT MIN(id) FROM noUsersOnline);
	SET @endId = (SELECT MAX(id) FROM noUsersOnline);  
	
	DROP TABLE IF EXISTS idTable;
	CREATE TEMPORARY TABLE idTable AS (
		SELECT nuo.id, nuo.startTime, nuo.endTime,
			CASE 
				WHEN nuo.id = @startId THEN "start"
				WHEN nuo.id = ids.id THEN "end"
				WHEN nuo.id = ids.next_id THEN "start"
				WHEN nuo.id = @endId THEN "end"
			END AS 'type'	
		FROM noUsersOnline nuo  
		LEFT OUTER JOIN (
			
			SELECT a AS id, b AS next_id
			FROM (
				SELECT a1.id AS a, MIN(a2.id) AS b
				FROM noUsersOnline AS a1
				LEFT JOIN noUsersOnline2 AS a2 ON a2.id > a1.id
				GROUP BY a1.id
				) AS tab
			WHERE b > a + 1) 
		AS ids ON (nuo.id = @startId OR ids.id = nuo.id OR ids.next_id = nuo.id OR nuo.id = @endId)
		GROUP BY nuo.id
		ORDER BY nuo.id
	);
	
	
	DROP TABLE IF EXISTS idTable2;
	CREATE TEMPORARY TABLE idTable2 AS (SELECT * FROM idTable);
	
	
	SELECT t1.id AS "startId", t2.id AS "endId", t1.startTime AS "Start Time", MIN(t2.endTime) AS "End Time"
	FROM idTable AS t1
	LEFT OUTER JOIN idTable2 AS t2 ON t2.id > t1.id
	WHERE t2.id IS NOT NULL
	AND t1.type = "start" AND t2.type = "end"
	GROUP BY t1.id;
	
END;

