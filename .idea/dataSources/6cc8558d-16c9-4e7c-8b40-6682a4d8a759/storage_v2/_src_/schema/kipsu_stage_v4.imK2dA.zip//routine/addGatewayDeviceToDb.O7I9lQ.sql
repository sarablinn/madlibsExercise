create
    definer = user@localhost procedure addGatewayDeviceToDb(IN smeagleName varchar(50), IN smeaglePassword varchar(50))
    comment 'Add newly provisioned SMSEagle devices to the database


Parameters:

- smeagleName - The name of the device, smeagleXXX

- smeaglePassword - The user_password for the device, found in group_vars/us_east_1_vpn.yml'
proc:BEGIN



    

    SET @procedureName := 'addGatewayDeviceToDb';

    SET @tablesAffected := 'gateway_device';

    SET @variablesProvided := CONCAT('smeagle_name: ', smeagleName, 'smeagle_password: ', smeaglePassword);

    SET @rowsAffected := 0;


     

    IF (smeagleName = '') THEN 

        SELECT ('Please provide a valid smeagle_name'); 

        LEAVE proc; 

    END IF; 


    

    IF (smeaglePassword = '') THEN 

        SELECT ('Please provide a valid smeagle_password'); 

        LEAVE proc; 

    END IF; 


    

    IF EXISTS(SELECT 1 FROM `gateway_device` WHERE `username` = smeagleName) THEN

        SELECT CONCAT('smeagle_name "', smeagleName, '" already exists! Please provide a new and valid smeagle_name');

        LEAVE proc; 

    END IF; 


    

    IF EXISTS(SELECT 1 FROM `gateway_device` WHERE `password` = smeaglePassword) THEN

        SELECT CONCAT('smeagle_password "', smeaglePassword, '" already exists! Please provide a new and valid smeagle_password');

        LEAVE proc; 

    END IF; 


    

    INSERT INTO `gateway_device` (`username`, `password`)

        VALUES (smeagleName, smeaglePassword);

        SET @rowsAffected := @rowsAffected + ROW_COUNT();



END;

