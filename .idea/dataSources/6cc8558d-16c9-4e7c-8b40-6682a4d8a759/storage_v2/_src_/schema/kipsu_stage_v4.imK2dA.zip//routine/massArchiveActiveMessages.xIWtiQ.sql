create
    definer = user@localhost procedure massArchiveActiveMessages(IN companyId int, IN startTime int, IN endTime int)
    comment 'Mass archive active messages for a site in a given timestamp range

Parameters:
- companyId - The ID of the company for which to archive the active messages
- startTime - The timestamp of the oldest message to be archived
- endTime - The timestamp of the most recent message to be archived'
proc:BEGIN
    
    


    
    SET @procedureName := 'massArchiveActiveMessages';
    SET @tablesAffected := 'categories, user, meta, action, categories_issue, message';
    SET @variablesProvided := CONCAT('companyId: ', companyId, ', startTime: ', startTime, ', endTime: ', endTime);
    SET @rowsAffected := 0;

    
    SET @categoryName := 'System Archived';
    SET @systemUser := CONCAT('system_archive_user_', companyId);

    
    IF (companyId = '') THEN 
        SELECT ('Please provide a valid company_id'); 
        LEAVE proc; 
    END IF; 
    
    
    IF (startTime = '') THEN 
        SELECT ('Please provide a valid startTime'); 
        LEAVE proc; 
    END IF; 

    
    IF (endTime = '') THEN 
        SELECT ('Please provide a valid endTime'); 
        LEAVE proc; 
    END IF;

    
    IF NOT EXISTS (SELECT 1 FROM `company` WHERE `company_id` = companyId) THEN
        SELECT CONCAT('company_id "', companyId, '" not found! Please provide a valid company_id');
        LEAVE proc; 
    END IF;

    
    IF (endTime < startTime) THEN 
        SELECT ('Please provide an endTime after the startTime'); 
        LEAVE proc; 
    END IF; 

    
    IF ((endTime - startTime) > (6 * 30 * 24 * 60 * 60)) THEN 
        SELECT ('Please choose a smaller time range'); 
        LEAVE proc; 
    END IF; 
    
    

    
    INSERT IGNORE INTO `categories` (`name`, `company_id`, `description`, `order`, `hidden`)
        SELECT @categoryName, companyId, 'Category for Automatically Archived Conversation', 1, 'yes'
        FROM DUAL
        WHERE NOT EXISTS(
            SELECT `id` 
            FROM `categories` 
            WHERE `company_id` = companyId 
                AND `name` = @categoryName);
    
    SET @categoryId = (
        SELECT `id` 
        FROM `categories` 
        WHERE `company_id` = companyId 
            AND `name` = @categoryName);

    
    INSERT INTO `user` (`role_id`, `username`, `created_on`)
        SELECT (SELECT `id` FROM `role` WHERE `name` = 'system'), @systemUser, UNIX_TIMESTAMP()
        FROM DUAL
        WHERE NOT EXISTS(
            SELECT `id` 
            FROM `user` 
            WHERE `role_id` = (SELECT `id` FROM `role` WHERE `name` = 'system') 
                AND `username` = @systemUser);
    
    SET @userId = (
        SELECT `id` 
        FROM `user` WHERE `role_id` = (SELECT `id` FROM `role` WHERE `name` = 'system')
            AND `username` = @systemUser);

    
    INSERT INTO `meta` (`user_id`, `first_name`, `last_name`, `company_id`, `context_id`, `system_language_id`)
        SELECT @userId, 'System', 'Archiver', companyId, companyId, (SELECT `language_id` FROM `language` WHERE `name` = 'English')
        FROM DUAL
        WHERE NOT EXISTS(
            SELECT `id` 
            FROM `meta` 
            WHERE `user_id` = @userId);

    
    DROP TABLE IF EXISTS `issue_archival_records`;
    CREATE TABLE `issue_archival_records` (
        `issue_id` BIGINT(20) UNSIGNED NOT NULL,
        `archive_timestamp` INT UNSIGNED,
        PRIMARY KEY (`issue_id`));

    
    INSERT INTO `issue_archival_records` (`issue_id`, `archive_timestamp`)
        SELECT `i`.`issue_id`, MAX(`m`.`timestamp`)
        FROM `message` m
        INNER JOIN `issue` i ON `m`.`issue_id` = `i`.`issue_id`
        INNER JOIN `convo` c ON `i`.`convo_id` = `c`.`convo_id`
        WHERE `m`.`timestamp` BETWEEN startTime AND endTime
            AND `c`.`company_id` = companyId
        GROUP BY `i`.`issue_id`;

    
    UPDATE `issue_archival_records` iar
    INNER JOIN (
        SELECT `m`.`issue_id`, MAX(`m`.`timestamp`) as `max_timestamp` 
        FROM `message` m 
        INNER JOIN `issue_archival_records` iar2 ON `m`.`issue_id` = `iar2`.`issue_id` 
        GROUP BY `iar2`.`issue_id`) AS `issue_max_timestamp` 
        ON `iar`.`issue_id` = `issue_max_timestamp`.`issue_id`
    SET `archive_timestamp` = `issue_max_timestamp`.`max_timestamp`;

    
    INSERT IGNORE INTO `action` (`issue_id`, `user_id`, `action`, `timestamp`)
    SELECT `issue_id`, @userId, 'completed_by', `archive_timestamp`
    FROM `issue_archival_records`;

    
    INSERT INTO `categories_issues` (`category_id`, `issue_id`)
    SELECT @categoryId, `iar`.`issue_id`
    FROM `issue_archival_records` iar
    LEFT OUTER JOIN `categories_issues` ci ON `iar`.`issue_id` = `ci`.`issue_id`
    WHERE `ci`.`issue_id` IS NULL;

    
    UPDATE `message` m
    INNER JOIN `issue` i ON `m`.`issue_id` = `i`.`issue_id`
    INNER JOIN `convo` c ON `i`.`convo_id` = `c`.`convo_id`
    INNER JOIN `issue_archival_records` iar ON `m`.`issue_id` = `iar`.`issue_id`
    SET `m`.`status` = 'archived'
    WHERE `m`.`status` IN ('active', 'unread', 'overdue')
        AND `c`.`company_id` = companyId;
    SET @rowsAffected := @rowsAffected + ROW_COUNT();

END;

